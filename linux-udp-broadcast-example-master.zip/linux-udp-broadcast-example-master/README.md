# linux-udp-broadcast-example
an example to use udp to boradcast

server runs in the bg, client send udp broadcast message to the wlan, and server got the message ,then send back a message to client, so client can got the server ip.
